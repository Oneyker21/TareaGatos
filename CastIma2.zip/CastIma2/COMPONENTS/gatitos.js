import {React } from 'react';
import {Text, View } from 'react-native';

function Gatitos(props){
    return (
        <View>
            <Image style={styles.gatos} source={props.imagen}/>
            <text style={styles.titulo}>{props.nombre}</text>
        </View>
    );
}

export default Gatitos;
const styles = StyleSheet.create({
    gato:{
        marginTop:10,
        borderRadius:8,
        width:300,
        height:300,
    },
    titulo:{
        fontSize:12,
        fontWeight:'bold',
        color:'blue',
    }
})