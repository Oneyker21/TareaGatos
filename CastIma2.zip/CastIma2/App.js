import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Gatitos from './COMPONENTS/gatitos';

export default function App() {
  return (
    <View style={styles.container}>
      <ScrollView>
        <Text style={styles.tituloText} >Galeria Gatos</Text>
        <Gatitos
          nombre='gatitos1'
          imagen={require('./IMAGENES/1.jpeg')}
        ></Gatitos>
        <Gatitos
          nombre='gatitos2'
          imagen={require('./IMAGENES/2.png')}
        ></Gatitos>
        <Gatitos
          nombre='gatitos3'
          imagen={require('./IMAGENES/3.jpg')}
        ></Gatitos>
        <Gatitos
          nombre='gatitos4'
          imagen={require('./IMAGENES/4.jpg')}
        ></Gatitos>
        <Gatitos
          nombre='gatitos5'
          imagen={require('./IMAGENES/5.jpg')}
        ></Gatitos>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop:30,
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tituloText:{
    fontSize: 12,
    fontWeight: 'bold',
  },
});
